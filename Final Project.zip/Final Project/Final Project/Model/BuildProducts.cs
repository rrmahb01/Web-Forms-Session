﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Final_Project.Controller;

namespace Final_Project.Model
{
    public class BuildProducts
    {
        List<Product> prod = new List<Product>(); //list for books and dvds

        public BuildProducts()
        {
            //creating books and adding them to prod
            Product book1 = new Product();
            book1.ProductID = 101;
            book1.Title = "Big Data: A Revolution That Will Transform How We Live, Work, and Think";
            book1.Price = 50.55;
            prod.Add(book1);

            Product book2 = new Product();
            book2.ProductID = 102;
            book2.Title = "Disruptive Possibilities: How Big Data Changes Everything";
            book2.Price = 65.67;
            prod.Add(book2);

            Product book3 = new Product();
            book3.ProductID = 103;
            book3.Title = "Data Smart: Using Data Science to Transform Information Into Insight";
            book3.Price = 32.78;
            prod.Add(book3);

            Product book4 = new Product();
            book4.ProductID = 104;
            book4.Title = "Big Data: Principles and Best Practices of Scalable Realtime Data Systems";
            book4.Price = 90.65;
            prod.Add(book4);

            Product book5 = new Product();
            book5.ProductID = 105;
            book5.Title = "Big Data Science & Analytics: A Hands-On Approach";
            book5.Price = 15.25;
            prod.Add(book5);

            //creating dvds and adding them to prod
            Product dvd1 = new Product();
            dvd1.ProductID = 201;
            dvd1.Title = "The Grand Tour Season 1";
            dvd1.Price = 10;
            prod.Add(dvd1);

            Product dvd2 = new Product();
            dvd2.ProductID = 202;
            dvd2.Title = "Spectre";
            dvd2.Price = 11.99;
            prod.Add(dvd2);

            Product dvd3 = new Product();
            dvd3.ProductID = 203;
            dvd3.Title = "Goliath Season 1";
            dvd3.Price = 12.99;
            prod.Add(dvd3);

            Product dvd4 = new Product();
            dvd4.ProductID = 204;
            dvd4.Title = "The Hunger Games: Mockingjay Part 2";
            dvd4.Price = 10.99;
            prod.Add(dvd4);

            Product dvd5 = new Product();
            dvd5.ProductID = 205;
            dvd5.Title = "Good Girls Revolt";
            dvd5.Price = 11.99;
            prod.Add(dvd5);

            HttpContext.Current.Session.Add("AllProducts", prod); //add prod to session under AllProducts
        }
        
    }
}