﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Final_Project.Controller
{
    public class CartObject
    {
        //backing fields
        private int _quantity;
        private Product _obj;

        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; }
        }

        public Product Obj
        {
            get { return _obj; }
            set { _obj = value; }
        }

        //accepts an int and Product parameter
        public CartObject( int qty, Product obj)
        {
            Quantity = qty;
            Obj = obj;
        }

        //ovverides ToString to show book/dvd title and total price w/o discount
        public override string ToString()
        {
            return String.Format("{0} - {1:C2}",
                Obj.Title, (Quantity*Obj.Price));
        }
    }
}