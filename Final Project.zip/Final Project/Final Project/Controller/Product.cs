﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Final_Project
{
    public class Product
    {
        //backing fields
        private string _productType;
        private int _productID;
        private string _title;
        private double _price;

        public String ProductType
        {
            get { return _productType; }
            set { _productType = value; }
        }

        public int ProductID
        {
            get { return _productID; }
            set { _productID = value; }
        }

        public String Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public Double Price
        {
            get { return _price; }
            set { _price = value; }
        }

        //returns discount percentage
        public Double discountPercentage( int quantity)
        {
            if (quantity <= 2)
                return 0;
            else if (quantity >= 5)
                return 0.05;
            else
                return 0.02;
        }

    }
}