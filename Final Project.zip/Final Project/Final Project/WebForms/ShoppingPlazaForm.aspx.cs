﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Final_Project.Model;
using Final_Project.Controller;

namespace Final_Project.WebForms
{
    public partial class ShoppingPlazaForm : System.Web.UI.Page
    {
        List<Product> allProducts = new List<Product>(); //list for products all products in session

        protected void Page_Load(object sender, EventArgs e)
        {
            BuildProducts bp = new BuildProducts(); //initiates created books, dvds, and session
            allProducts = (List<Product>)Session["AllProducts"]; //adds session to allProducts

            //if IsPostBack is false - will only execute the first time the page loads
            if (!IsPostBack)
            {
                List<Product> books = new List<Product>(); //list for only books
                List<Product> dvds = new List<Product>(); //list for only dvds

                foreach (Product p in allProducts)
                {
                    if (p.ProductID >= 200)
                        dvds.Add(p); //add the dvds to the list
                    else
                        books.Add(p); //add the books to the list
                }

                foreach (Product b in books)
                    BooksDrpDwnBx.Items.Add(b.Title); //add the book titles to the dropdownbox

                BookPriceLbl.Text = books[0].Price.ToString("C2"); //show the first book price in the lable

                foreach (Product d in dvds)
                    DVDDrpDwnBx.Items.Add(d.Title); //add the dvd titles to the dropdownbox

                DVDPriceLbl.Text = dvds[0].Price.ToString("C2"); //show the first dvd price in the lable

                HttpContext.Current.Session.Add("AllBooks", books); //add books to session under AllBooks
                HttpContext.Current.Session.Add("AllDVDs", dvds); //add dvds to session under AllDVDs
            }
        }

        protected void BooksDrpDwnBx_SelectedIndexChanged(object sender, EventArgs e) //AutoPostBack is true
        {
            List<Product> books = (List<Product>)Session["AllBooks"]; //create new list and set is as AllBooks

           int bookSelectIndex = BooksDrpDwnBx.SelectedIndex; //SelectedIndex of selected book

            if (bookSelectIndex != -1)
                BookPriceLbl.Text = books[bookSelectIndex].Price.ToString("C2"); //updates price with selected book's price
        }

        protected void DVDDrpDwnBx_SelectedIndexChanged(object sender, EventArgs e) //AutoPost is true
        {
            List<Product> dvds = (List<Product>)Session["AllDVDs"]; //create new list and set it as AllDVDs

            int dvdSelectIndex = DVDDrpDwnBx.SelectedIndex; //SelectedIndex of selected dvd

            if (dvdSelectIndex != -1)
                DVDPriceLbl.Text = dvds[dvdSelectIndex].Price.ToString("C2"); //updates price with selected dvd's price
        }

        protected void AddBtn_Click(object sender, EventArgs e)
        {
            List<Product> books = (List<Product>)Session["AllBooks"]; //create new list and set it as AllBooks
            List<Product> dvds = (List<Product>)Session["AllDVDs"]; //create new list and set it as AllDVDs
            List<CartObject> cart = new List<CartObject>(); //create new list of CartObjects

            if (Session["cart"] != null) //cart will remain null before the first time something is added
            {
                cart = (List<CartObject>)Session["cart"]; //after the first item is added, cart will be set to the 
            }

            int bookQty;
            if (int.TryParse(BookQtyTxtBx.Text, out bookQty)) { }
            else
                bookQty = 0; //set to zero if input cannot identify as an int

            int dvdQty;
            if (int.TryParse(DVDQtyTxtBx.Text, out dvdQty)) { }
            else
                dvdQty = 0; //set to zero if input cannot identify as an int

            if (bookQty <= 0 && dvdQty <= 0) //number > 0 must be in at least one text box
                MessageLbl.Text = "At least one product quantities must be > 0. Otherwise, click Exit.";
            else
            {
                if (bookQty > 0) //only executes if input is > 0
                {
                    int bookSelectIndex = BooksDrpDwnBx.SelectedIndex; //drop down box selected index
                    CartObject addBook = new CartObject(bookQty, books[bookSelectIndex]); //create new CartObject. obj is input from books
                    cart.Add(addBook); //add new CartObject to cart list
                    MessageLbl.Text = ""; //clear message label
                }

                if (dvdQty > 0) //only executes if input is > 0
                {
                    int dvdSelectIndex = DVDDrpDwnBx.SelectedIndex; //drop down box selected index
                    CartObject addDVD = new CartObject(dvdQty, dvds[dvdSelectIndex]); //create new CartObject. obj is input from books
                    cart.Add(addDVD); //add new CartObject to cart list
                    MessageLbl.Text = ""; //clear message label
                }
                HttpContext.Current.Session.Add("cart", cart); //add cart list to session under "cart"

                BookQtyTxtBx.Text = ""; //clear book quantity text box
                DVDQtyTxtBx.Text = ""; //clear dvd quantity text box
                MessageLbl.Text = "Success!"; //show success message
            }
        }

        protected void CheckoutBtn_Click(object sender, EventArgs e)
        {
            if (Session["cart"] == null) //cart session cannot empty
                MessageLbl.Text = "You must add at least one book or DVD. Otherwise, click Exit";
            else
                Response.Redirect("~/WebForms/CheckoutPage.aspx"); //go to checkout page
        }

        protected void ExitBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/WebForms/ExitPage.aspx"); //go to exit page
        }
    }
}