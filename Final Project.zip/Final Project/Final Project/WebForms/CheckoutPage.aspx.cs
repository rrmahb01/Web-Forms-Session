﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Final_Project.Controller;
using Final_Project.Model;

namespace Final_Project.WebForms
{
    public partial class CheckoutPage : System.Web.UI.Page
    {
        List<CartObject> cart = new List<CartObject>(); //create CartObject list to hold session list

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["cart"] != null) //only add the session to cart list if it's not empty. it should never be empty since an item is required to be in it to get to this page
                cart = (List<CartObject>)Session["cart"];

            if (!IsPostBack) //execute only first time page loads
            {
                foreach (CartObject c in cart)
                    CheckoutLB.Items.Add(c.ToString()); //add cart to checkout list box

                QtyTB.Enabled = false; //disable quantity text box
            }
        }

        protected void CheckoutLB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CheckoutLB.SelectedIndex != -1) //only execute if something is selected
            {
                CartObject SelectedCart = cart[CheckoutLB.SelectedIndex]; //selected cart

                QtyTB.Enabled = true; //enable quanity text box
                QtyTB.Text = SelectedCart.Quantity.ToString(); //quantity text box text porperty is set to selected cart's quantity
            }
            else
                QtyTB.Enabled = false; //quantiy text box remains disabled
        }

        protected void AcceptBtn_Click(object sender, EventArgs e)
        {
            if (CheckoutLB.SelectedIndex != -1) //only execute if something is selected
            {
                int quantity;
                if (int.TryParse(QtyTB.Text, out quantity))
                {
                    if (quantity < 0) //if quantiy is < 0, quantity = 0
                        quantity = 0;
                }
                else
                    quantity = 0; //if input cannot be parsed to an int, set quantity to 0
                    

                if (quantity != 0) //only execute if quantity is not 0
                {
                    CartObject SelectedCart = cart[CheckoutLB.SelectedIndex]; //selected cart

                    SelectedCart.Quantity = quantity; //selected cart's quantity is changed to inserted quantity
                    Session["cart"] = cart; //Session is changed to updated cart

                    //clear checkout list box then re-add cart to it
                    CheckoutLB.Items.Clear();
                    foreach (CartObject c in cart)
                        CheckoutLB.Items.Add(c.ToString());

                    MessageLbl.Text = "Your product quantity has been changed.";
                    QtyTB.Text = ""; //clear quantity text box
                    TotalLbl.Text = ""; //clear total text box
                    QtyTB.Enabled = false;
                }
                else //if quantity is 0
                {
                    CartObject SelectedCart = cart[CheckoutLB.SelectedIndex]; //selected cart

                    cart.Remove(SelectedCart); //remove CartObject from cart list
                    Session["cart"] = cart; //update cart session

                    //clear list box then re-add cart
                    CheckoutLB.Items.Clear();
                    foreach (CartObject c in cart)
                        CheckoutLB.Items.Add(c.ToString());

                    MessageLbl.Text = "Your product has been removed.";
                    QtyTB.Text = "";
                    TotalLbl.Text = "";
                    QtyTB.Enabled = false;
                }
            }
            else
                MessageLbl.Text = "Select a product. Otherwise click Exit.";
        }

        protected void ExitBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/WebForms/ExitPage.aspx");
        }

        protected void PayBtn_Click(object sender, EventArgs e)
        {
            if (CheckoutLB.Items.Count != 0) //if the list box has CartObjects in it
            {
                double price = 0;
                double discount = 0;

                foreach (CartObject c in cart)
                {
                    //calculations for discounted price and discount amount for each CartObject in cart
                    price += c.Obj.Price * c.Quantity * (1 - c.Obj.discountPercentage(c.Quantity));
                    discount += c.Obj.Price * c.Quantity * (c.Obj.discountPercentage(c.Quantity));
                }


                if (discount != 0) //if there is a discount
                    TotalLbl.Text = "Your total payment is " + price.ToString("C2") + ". You received a discount of " + discount.ToString("C2");
                else //if no discount
                    TotalLbl.Text = "Your total payment is " + price.ToString("C2") + ".";

                MessageLbl.Text = "";
            }
            else
            {
                MessageLbl.Text = "You have no items in your shopping cart. Click Exit.";
                TotalLbl.Text = "Error";
            }
        }
    }
}